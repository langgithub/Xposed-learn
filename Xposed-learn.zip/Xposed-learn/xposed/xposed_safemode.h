#ifndef XPOSED_SAFEMODE_H_
#define XPOSED_SAFEMODE_H_

namespace xposed {

bool detectSafemodeTrigger(bool skipInitialDelay);

}

#endif  // XPOSED_SAFEMODE_H_

